---
title: Pages Filter

access:
    admin.pages: true
    admin.super: true
---
