# v1.4.1
## 12/11/2015

1. [](#bugfix)
    * Fixed CLI command for PHP 5.5 and lower

# v1.4.0
## 11/21/2015

1. [](#new)
    * Implemented CLI commands for the plugin

# v1.3.0
## 08/25/2015

1. [](#improved)
    * Added blueprints for Grav Admin plugin

# v1.2.2
## 01/06/2015

1. [](#new)
    * Added a default `error.json.twig` file

# v1.2.1
## 11/30/2014

1. [](#new)
    * ChangeLog started...
