---
title: Page not Found
robots: noindex,nofollow
template: error
routable: false
http_response_code: 404
errorheading: 'WHOOPS!'
errorcontent: 'Looks like the page you were looking for has been taken hostage by a baby.'
errorctaleft: 'Back to previous page'
errorctaleftlink: 'javascript:history.back()'
errorctaright: 'Check out some of my work'
errorctarightlink: '#work'
---
