---
title: 'i almost wasn’t…an extrovert'
taxonomy:
    tag: [marketing, communication, experience]
date: 05/19/2013
---
Campfire after-hours (theme: near miss) at CSz Portland: 5/19/2013

audio for attempts at extroversion

