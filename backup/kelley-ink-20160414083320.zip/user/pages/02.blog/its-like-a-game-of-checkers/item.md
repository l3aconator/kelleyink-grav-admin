---
title: 'it’s like a game of checkers'
taxonomy:
    tag: [story, the moth]
date: 01/07/2013
---
This was my first time chosen at The Moth. I'd tried both in October--the opening show--and November, but hadn't had my name picked out of the hat in either case. The plan for those two earlier ones were to tell Tire Rotation for the first one (theme: chemistry), and then in November to tell either that or the as-yet-untold and as of early 2013, incomplete, The Day That Changed My Life (theme: unintended).

The Moth StorySLAM (theme: outgrown), The Secret Society: 1/7/13

It wasn't broadcast, though it was recorded by The Moth. I will have to wait and, one of these days, I will tell it again and you will be able to hear it
