---
title: Blog
content:
    items: '@self.children'
    order:
        by: date
        dir: desc
        
blogheading: Kelley’s Blog
---
Here’s an overview of what I’m thinking and doing, as well as occasional project updates. Writing begets writing, you know.