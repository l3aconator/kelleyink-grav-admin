---
title: 'a tale of three roomates'
published: true
date: 02/07/2013
taxonomy:
    tag:
        - story
        - 'anecdotal evidence'
---

Anecdotal Evidence (theme: well, that was awkward) in Vancouver: 2/7/2013
(not recorded)
