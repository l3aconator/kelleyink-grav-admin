---
title: 'how i voted for the first time'
taxonomy:
    tag: [story, audio, campfire]
date: 08/19/2012
---
This was my first story-telling experience.
Campfire after-hours (theme: motivation) at CSz Portland: August 19, 2012

