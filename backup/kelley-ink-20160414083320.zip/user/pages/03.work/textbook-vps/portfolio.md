---
title: 'Textbook VPS'
order: 5

button: false
buttontext: 'See my coroflot portfolio!'

outsidebutton: true
outsidebuttontext: 'See my coroflot portfolio!'
outsidelink: http://www.coroflot.com/kamcalli/portfolio

bottomimage: bottom.jpg
topimage: top.jpg
footerimage: footer.jpg

caption: 'From my time in higher-ed: an in-textbook Visual Preface example.'
---

## Visual prefaces
I used to work in textbook publishing and many of the texts had built in marketing, called a VP, or visual preface. I worked on some while I freelanced as I transitioned back into the workforce from being a stay-at-home parent, and this old portfolio site contains a few examples from that time.