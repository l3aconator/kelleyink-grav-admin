---
title: 'Maxwell 3/e postcard'
order: 1

button: true
buttontext: 'See the pdf!'
pdf: alternative-care.pdf

bottomimage: bottom.jpg
topimage: top.jpg
footerimage: footer.jpg

caption: 'This new edition postcard confirmed expected changes for professors.'
---

## New edition mailer
When market-leading books come out in a new edition, the market needs the news promptly. The danger with any revision is that it’s an opportunity to make a change to a different book. (And if your book leads the market, that means you have a lot of market share to lose.) In this case, we had to make sure people expected the Third Edition, were aware of the limited number of changes to the book, and were reminded of why they liked it.