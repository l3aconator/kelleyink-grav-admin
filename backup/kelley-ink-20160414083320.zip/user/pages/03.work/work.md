---
title: Work
visible: false
content:
    items:
        - '@self.children'
---

