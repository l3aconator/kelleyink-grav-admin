---
title: 'Member newsletters'
order: 2

button: true
buttontext: 'See the pdf!'
pdf: newsletter-q3-2015.pdf

bottomimage: bottom.jpg
topimage: top.jpg
footerimage: footer.jpg

caption: 'This is one of our quarterly newsletters, sent to HRIC members.'
---

## Quarterly member newsletters
Member communication occurred in many forms: mailings, emails, via customer service, and also through our quarterly member newsletters. Our newsletters started with a message from the CEO (ghost-written by me) and continued on with a story about whatever was new and intriguing. We used a “Benefits 101” structure to keep members on the same page, and a “Marta’s Message” to communicate quality initiatives.