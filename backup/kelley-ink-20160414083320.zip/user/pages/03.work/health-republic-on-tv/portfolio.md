---
title: 'Health Republic on TV'
order: 9

button: false

outsidebutton: true
outsidebuttontext: 'See the commercial!'
outsidelink: 'https://www.youtube.com/watch?v=6nE0zb_OEuQ'

bottomimage: bottom.jpg
topimage: top.jpg
footerimage: footer.jpg

caption: 'Health Republic’s first commercial: written, voiced, PM’ed by me.'
---

## Television commercial
Our commercial for the individual market was designed to mirror the feel of our plan videos (see website case study for those examples). It had to be friendly, accessible, and trustworthy...providing a feeling of integrity while piquing interest by seeming like a different type of insurance company. I wrote, voiced, and PM’ed this.