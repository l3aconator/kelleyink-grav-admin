---
title: 'Education curriculum bundling'
order: 6

button: true
buttontext: 'See postcard PDF!'
pdf: alternative-care.pdf
bottomimage: bottom.jpg
topimage: top.jpg
footerimage: footer.jpg

caption: 'this is text that will be populated on the homepage preview'
---

## Offering bundle options
Used books cause financial challenges for publishers...in fact, they are the root cause of the pricing crisis that students and the industry are facing now. “Bundling” books is a win-win: more books at a discount for the students, and new books sold for publishers. In some cases, like this one, two titles are the perfect match to complement one another and sell together.