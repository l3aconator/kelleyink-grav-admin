---
title: '2015 plan overview'
order: 10

button: true
buttontext: 'See the side-by-side checklist!'
pdf: 2015-hric-plans-and-networks.pdf

bottomimage: bottom.jpg
topimage: top.jpg
footerimage: footer.jpg

caption: 'One of my all-time favorites: a checklist-style plan comparison.'
---

##  Checklists ftw!
One way to decide on a plan is to decide which company you want to use...another is to decide which plan type within a company works for you. This color-coded checklist was an at-a-glance plan comparison of offerings within plan types which made visual sense of an otherwise overwhelming set of options. It became the single most popular piece of collateral we’d created.