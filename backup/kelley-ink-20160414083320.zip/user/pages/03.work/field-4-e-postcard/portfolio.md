---
title: 'Field 4/e postcard'
order: 8

button: true
buttontext: 'See postcard PDF!'
pdf: field-4e-postcard.pdf

bottomimage: bottom.jpg
topimage: top.jpg
footerimage: footer.jpg

caption: 'This new edition postcard showcased popular in-book personas.'
---

## Showcasing strengths
This title by well-known stats author Andy Field is beloved for the quirky and beloved characters throughout the book, and this edition offered two new ones! The request for this postcard was to play to the popularity of those personas, and we chose to achieve that by offering a way to invest further by identifying with one of them. Play to the strengths that are already resonating with the market!