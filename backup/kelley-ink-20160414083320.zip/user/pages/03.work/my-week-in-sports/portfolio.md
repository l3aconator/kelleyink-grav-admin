---
title: 'My week in sports'
order: 3

button: false

outsidebutton: true
outsidebuttontext: 'Experience my sports-blogger persona!'
outsidelink: 'http://myweekinsports.blogspot.com/'

bottomimage: bottom.jpg
topimage: top.jpg
footerimage: footer.jpg

caption: 'Silly, satirical...my knowledge of sports. (Or, the lack thereof.) '
---

## Sports-blogging
My friends know me as someone who knows essentially nothing about sports and begged me to apply my signature brand of silly to some sports write-ups. I let it peter out when it became clear that in order to continually satirize sports, I was going to have to continually watch sports!