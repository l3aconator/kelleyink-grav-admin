---
title: 'Ink Blot'
---
Here’s an overview of what I’m thinking and doing, as well as occasional project updates. Writing begets writing, you know.