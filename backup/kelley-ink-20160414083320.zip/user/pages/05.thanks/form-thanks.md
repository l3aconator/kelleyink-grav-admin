---
title: 'Email Thanks'
visible: false
robots: noindex,nofollow

thanksheading: 'Thanks for writing!'
thankscontent: 'I’ll respond as soon as possible, and in the meantime, my daughters and I hope you have a wonderful day.'

thanksctaleft: 'Back to previous page'
thanksctaleftlink: 'javascript:history.back()'

thanksctaright: 'See what I’m up to in my blog!'
thanksctarightlink: '/blog'
---

# Thanks for your email!