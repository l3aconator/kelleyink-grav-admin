---
title: 'the last teenage years'
taxonomy:
    tag: [story, audio, campfire]
date: 12/16/2012
---
Campfire after-hours (theme: first time) at CSz Portland: 12/16/12

[Audio here »](https://soundcloud.com/campfire-storytelling/kelley-tyner-alzheimers?in=kamcalli/sets/kelley-tyner-mcallister)