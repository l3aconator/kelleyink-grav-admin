---
title: 'the ladder'
taxonomy:
    tag:
        - marketing
        - communication
        - experience
date: 01/01/2012
---

Anecdotal Evidence (theme: you want me to what?) in Vancouver: 11/1/12
(not recorded)

[Recording here »](https://soundcloud.com/campfire-storytelling/kelley-mcallister-serial?in=kamcalli/sets/kelley-tyner-mcallister?target=_blank)
