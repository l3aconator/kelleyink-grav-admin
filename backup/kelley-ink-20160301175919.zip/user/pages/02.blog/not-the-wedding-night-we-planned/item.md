---
title: 'not the wedding night we planned'
taxonomy:
    tag:
        - story
        - peachy
        - host
date: 05/03/2013
---

This was my fourth Peachy hosting, and the first time I ever tested a completely new story in this venue. 
(My first time with Peachy, I told a "new" story, but it was one I'd planned to tell several times at The Moth, so it didn't feel quite as raw. That one, Tire Rotation, was eventually [re-told and recorded at Campfire](http://kelleytynermcallisterstories.blogspot.com/2013/03/well-that-hurt.html?target=_blank), under the theme of Get Lucky.) 
This was the story of getting naked on my first wedding night, a.k.a. not the wedding night we planned.

Peachy Chicken host and monologist for First Friday Improvisational at The Oregon Public House: 5/3/2013
(not recorded)
