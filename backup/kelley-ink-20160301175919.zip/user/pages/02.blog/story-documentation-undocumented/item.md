---
title: 'story documentation...undocumented'
taxonomy:
    tag: [story, story class]
date: 05/19/2013
---
Did I stop telling stories between May of 2013 and the start of 2016? Heck, no. But...I kinda stopped documenting it. I regret that, but I suppose in the scheme of life regrets, it’s not the end of the world. 

In my defense, I had a lot on my plate: a divorce, a new relationship, a move from a job for an established company to a start-up, the failure of that start-up, job-hunting, a new job at another start-up (this time, one I was truly passionate about), a new baby, the demise of the second start-up...and now we’re here at job-hunting again. 

During that grayed-out period in my story history, I told numerous additional stories at Peachy Chicken. I hosted and storytold at The Invite. I transitioned Campfire to a joint venture called Campfire@ with a friend of mine (the former head of Anecdotal Evidence), where she and I hosted a year’s worth of story shows through Campfire@Curious at Curious Comedy Theater. I told a story or two at Kickstand. I taught another 4-week class at ComedySportz Portland and again at Curious Comedy. 

Since 2015, I started taking it easy, though, due to pregnancy and the birth of my second daughter. I still tell occasionally, though, and have started expanding the range of ages I teach by doing a 3-week workshop for Girl Scouts and beginning to build a curriculum for what I hope will eventually become a class for senior citizens. I also offer story coaching on demand.
