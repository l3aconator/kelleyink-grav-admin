---
title: manhattan
taxonomy:
    tag:
        - story
        - audio
        - campfire
date: 01/20/2013
---

Campfire after-hours (theme: resolution) at CSz Portland: 1/20/13

[Audio »](https://soundcloud.com/kamcalli/kelley-tyner-mcallister?target=_blank)