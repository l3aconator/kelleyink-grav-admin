---
title: Blog
content:
    items: '@self.children'
---