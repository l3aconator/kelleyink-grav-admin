---
title: 'serial killer redux'
taxonomy:
    tag:
        - story
        - audio
        - peachy
        - host
date: 02/01/2013
---

First re-telling of a story, that of the serial killer couple.
Peachy Chicken host and monologist for First Friday Improvisational at The Oregon Public House: 2/1/2013
(not recorded) 
