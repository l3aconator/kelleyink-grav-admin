---
title: 'well, that hurt'
taxonomy:
    tag:
        - story
        - audio
        - campfire
date: 03/17/2013
---

Campfire after-hours (theme: get lucky) at CSz Portland: 3/17/2013

[audio for Well, That Hurt](https://soundcloud.com/kamcalli/kelley-tyner-mcallister-well?target=_blank)