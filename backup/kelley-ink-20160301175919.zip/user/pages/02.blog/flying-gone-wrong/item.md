---
title: 'flying gone wrong'
taxonomy:
    tag:
        - story
        - audio
        - campfire
        - 'story class'
date: 01/26/2016
---

Campfire after-hours (theme: curveball) at CSz Portland: 4/29/2013
...also! notably!, this was the first show populated by my storytelling workshop. Visit [the Curveball Campfire page](http://campfirestorytelling.wordpress.com/2013/05/10/theme-curveball/?target=_blank) for more details, and audio of the class performances...

audio for [Flying Gone Wrong](https://soundcloud.com/kamcalli/flying-gone-wrong?target=_blank)

