---
title: 'serial killer couple'
taxonomy:
    tag:
        - story
        - audio
        - campfire
date: 10/21/2012
---

Campfire after-hours (theme: roll the dice) at CSz Portland: 10/21/12

[Audio »](https://soundcloud.com/campfire-storytelling/kelley-mcallister-serial?in=kamcalli/sets/kelley-tyner-mcallister)