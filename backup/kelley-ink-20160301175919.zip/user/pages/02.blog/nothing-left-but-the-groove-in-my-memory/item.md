---
title: 'nothing left but the groove in my memory'
taxonomy:
    tag:
        - story
        - 'the moth'
date: 03/14/2013
---

The Moth StorySLAM (theme: detours), The Secret Society: 3/4/13

This was my second time chosen at The Moth, and it did not go particularly well. I am starting to wonder if I have a lot of difficulty with the 5 minute limit?...I think I don't let the story breathe the way I should. I had trouble coming up with this story, and then thought I loved it (the story of our ritualistic annual drive to Lake Havasu), and was disappointed. Am retelling it in May at Anecdotal Evidence and am hoping for the best. 

I had gone to The Moth in February (theme: love hurts) and hoped to tell the tire rotation story, but not been chosen. After being chosen this time (theme: detours) I started to wonder whether the “tire rotation”/”well,that hurt” story was cursed, at The Moth. :-) 

This story wasn't broadcast, though it was recorded by The Moth. It won't be recorded at Anecdotal Evidence, either, so you'll have to wait to hear it until I decide to tell it at Campfire!

(note from mid-May: I haven't been back to The Moth since this story. Too many other stories going on, between Campfire, my storytelling workshop, Peachy hosting, and Anecdotal Evidence. Still, I'd like to work on how to be successful in this sort of a venue. It'll be a longer-term goal for me, I suppose.)