---
title: 'storytelling class performance '
taxonomy:
    tag:
        - story
        - audio
        - campfire
        - 'story class'
date: 05/19/2013
---

I’ve taught a storytelling series many times, but this is the first (and so far, only) one to be completely recorded. It was so amazing to watch my students perform their stories after workshopping them for more than a month. I was exceedingly proud, and my love of teaching story was officially born.

[Here](https://campfirestorytelling.wordpress.com/2013/05/19/theme-near-miss/?target=_blank) is the page from the old Campfire site on which we posted audio from the performance. Enjoy!