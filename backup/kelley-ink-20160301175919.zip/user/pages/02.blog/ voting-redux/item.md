---
title: 'voting (redux)'
taxonomy:
    tag:
        - story
        - peachy
        - host
date: 04/05/2013
---

For this hosting event, I retold my first-ever story, how I voted for the first time. This was my third time as Peachy Chicken host and monologist for First Friday Improvisational at The Oregon Public House: 4/5/2013

[Audio »](http://kelleytynermcallisterstories.blogspot.com/2012/08/how-i-voted-for-first-time.html?target=_blank)