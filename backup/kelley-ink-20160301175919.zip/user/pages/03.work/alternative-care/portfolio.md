---
title: 'Alternative Care One-pager'
button: true
buttontext: 'See the pdf!'
pdf: alternative-care.pdf
bottomimage: bottom.jpg
topimage: top.jpg
footerimage: footer.jpg
---

## Project Overview
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget odio. 

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet