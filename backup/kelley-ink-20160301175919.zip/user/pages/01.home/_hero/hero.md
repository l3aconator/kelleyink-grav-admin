---
title: Hero
visible: false
text: 'Precision of workds doesn’t have to be a lost art. I care passionately about communication and about finding the right words.'
---

