---
title: About
visible: false
---

## Nice to meet you. I’m Kelley.
 

I’m a writer, a marketer, a teller of stories...above all, a communicator. What can I do for you? Well, if you know what it is you want (marketing strategy, editorial guidance, content for any venue, an invigorated social media presence or corporate voice), I can provide it for you. If you...and you’d be surprised at how common this is...if you don’t know quite what it is you need, let’s brainstorm and I’ll help you conceptualize it.