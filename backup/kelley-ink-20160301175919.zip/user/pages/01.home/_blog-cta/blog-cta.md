---
title: 'Blog CTA'
---

### The Ink Blot

Lorem