---
title: Blog
---

### The Ink Blot

Lorem