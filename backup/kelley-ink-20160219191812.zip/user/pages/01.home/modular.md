---
title: Homepage
menu: Home
onpage_menu: false
body_classes: ""

content:
    items: '@self.modular'
    order:
        by: default
        dir: asc
        custom:
            - _about
            - _services
            - _work
            - _contact
            - _blog
---
